total = 0;
for x in range (0,101,2):
    total += x

print(total)